# ECSE-316 - Assignment 1
Written By Vadim Tuchila and Filip Piekarek

Instructions to run the app:
1. Compile the app:
		
		javac DnsClient.java 

2. Run the app with arguments:
	
	java DnsClient [-t timeout] [-r max-retries] [-p port] [-mx|-ns] @server name 

	Example:

	java DnsClient 8.8.8.8 mcgill.ca 



---------------------------------------------------------------------------------

Java Version Used When Writing The App: 

	java version "11.0.8" 2020-07-14 LTS
	Java(TM) SE Runtime Environment 18.9 (build 11.0.8+10-LTS)
	Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.8+10-LTS, mixed mode)


---------------------------------------------------------------------------------